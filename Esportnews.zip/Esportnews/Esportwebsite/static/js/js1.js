function Alert(){
    alert("คุณไม่ได้รับอนุญาติ")
    console.log("คุณไม่ได้รับอนุญาติ")
}